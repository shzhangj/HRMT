﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRMTWeb.Models
{
    public class OrderContainer
    {
        public List<OrderInfo> OrderList { get; set; }
    }
}